import unittest
from utils.base import BaseTest
from utils.locators import GuviLocators
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class GuviTestSuite(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        cls.base_test = BaseTest(browser="chrome")
        cls.url = "https://www.guvi.in"

    def test_url_validity(self):
        """Test Case 1: Check URL validity"""
        self.base_test.open_url(self.url)
        self.assertIn("guvi.in", self.base_test.driver.current_url)

    def test_page_title(self):
        """Test Case 2: Check webpage title"""
        self.assertIn("GUVI", self.base_test.driver.title)

    def test_login_button_visibility(self):
        """Test Case 3: Check Login button visibility and clickability"""
        login_btn = self.base_test.find_element(*GuviLocators.LOGIN_BUTTON)
        self.assertIsNotNone(login_btn)
        self.assertTrue(login_btn.is_displayed())
        self.assertTrue(login_btn.is_enabled())

    def test_signup_button_visibility(self):
        """Test Case 4: Check Signup button visibility and clickability"""
        signup_btn = self.base_test.find_element(*GuviLocators.SIGNUP_BUTTON)
        self.assertIsNotNone(signup_btn)
        self.assertTrue(signup_btn.is_displayed())
        self.assertTrue(signup_btn.is_enabled())

    def test_signup_navigation(self):
        """Test Case 5: Test Sign-Up button navigation"""
        signup_btn = self.base_test.find_element(*GuviLocators.SIGNUP_BUTTON)
        signup_btn.click()
        self.assertIn("sign-in", self.base_test.driver.current_url)

    def test_valid_login(self):
        """Test Case 6: Login with valid credentials"""
        self.base_test.open_url(self.url + "/sign-in/")
        self.base_test.find_element(*GuviLocators.EMAIL_INPUT).send_keys("valid_email@example.com")
        self.base_test.find_element(*GuviLocators.PASSWORD_INPUT).send_keys("valid_password")
        self.base_test.find_element(*GuviLocators.LOGIN_SUBMIT).click()
        self.assertTrue(self.base_test.find_element(*GuviLocators.LOGOUT_BUTTON).is_displayed())

    def test_invalid_login(self):
        """Test Case 7: Login with invalid credentials"""
        self.base_test.open_url(self.url + "/sign-in/")
        self.base_test.find_element(*GuviLocators.EMAIL_INPUT).send_keys("invalid_email@example.com")
        self.base_test.find_element(*GuviLocators.PASSWORD_INPUT).send_keys("invalid_password")
        self.base_test.find_element(*GuviLocators.LOGIN_SUBMIT).click()
        error_msg = self.base_test.find_element(By.CLASS_NAME, "error")  # Replace with actual class
        self.assertIn("Invalid credentials", error_msg.text)

    @classmethod
    def tearDownClass(cls):
        cls.base_test.close_browser()

if __name__ == "__main__":
    unittest.main()
