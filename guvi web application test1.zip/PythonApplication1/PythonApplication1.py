from selenium import webdriver
from selenium.webdriver.common.by import By

class BaseTest:
    def __init__(self, browser="chrome"):
        """
        Initialize the browser driver.
        Supported browsers: chrome, firefox, edge.
        """
        try:
            browser = browser.lower()
            if browser == "chrome":
                self.driver = webdriver.Chrome()
            elif browser == "firefox":
                self.driver = webdriver.Firefox()
            elif browser == "edge":
                self.driver = webdriver.Edge()
            else:
                raise ValueError(f"Unsupported browser '{browser}'. Supported: chrome, firefox, edge.")
            
            self.driver.implicitly_wait(10)
            self.driver.maximize_window()
            print(f"{browser.capitalize()} browser initialized successfully.")
        except Exception as e:
            print(f"Error initializing the browser: {e}")
            raise
    
    def open_url(self, url):
        """
        Open a specified URL.
        :param url: The URL to navigate to.
        """
        try:
            self.driver.get(url)
            print(f"Successfully opened URL: {url}")
        except Exception as e:
            print(f"Failed to open URL: {url}. Error: {e}")
            raise
    
    def close_browser(self):
        """
        Close the browser and quit the driver.
        """
        try:
            if self.driver:
                self.driver.quit()
                print("Browser closed successfully.")
        except Exception as e:
            print(f"Error closing the browser: {e}")
            raise
    
    def find_element(self, by, value):
        """
        Find an element on the webpage.
        :param by: Locator strategy (e.g., By.ID, By.NAME).
        :param value: Locator value.
        :return: WebElement if found, None otherwise.
        """
        try:
            element = self.driver.find_element(by, value)
            print(f"Element found: {by}='{value}'")
            return element
        except Exception as e:
            print(f"Failed to find element by {by} with value '{value}': {e}")
            return None
