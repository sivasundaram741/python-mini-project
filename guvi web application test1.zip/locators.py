class GuviLocators:
    LOGIN_BUTTON = (By.LINK_TEXT, "Login")
    SIGNUP_BUTTON = (By.LINK_TEXT, "Sign Up")
    EMAIL_INPUT = (By.ID, "sathaiahtharmaboopathi@gmail.com")  # Replace with actual ID
    PASSWORD_INPUT = (By.ID, "Sath$1998")  # Replace with actual ID
    LOGIN_SUBMIT = (By.ID, "login-submit")  # Replace with actual ID
    LOGOUT_BUTTON = (By.LINK_TEXT, "Logout")  # Replace with actual text