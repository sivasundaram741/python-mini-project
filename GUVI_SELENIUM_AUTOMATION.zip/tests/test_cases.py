import unittest
from utils.base import BaseTest
from utils.locators import GuviLocators

class GuviAutomationTests(BaseTest, unittest.TestCase):
    """Test Suite for automating GUVI website."""

    @classmethod
    def setUpClass(cls):
        cls.test = BaseTest()
        cls.url = "https://www.guvi.in"

    def test_url_validity(self):
        """Test Case 1: Check URL validity."""
        self.test.open_url(self.url)
        self.assertIn("guvi.in", self.test.driver.current_url)

    def test_page_title(self):
        """Test Case 2: Check page title."""
        self.assertEqual(self.test.driver.title, "GUVI | Learn to code in your native language")

    def test_login_button(self):
        """Test Case 3: Validate Login button visibility and clickability."""
        login_button = self.test.driver.find_element(*GuviLocators.LOGIN_BUTTON)
        self.assertTrue(login_button.is_displayed())
        self.assertTrue(login_button.is_enabled())

    def test_signup_button(self):
        """Test Case 4: Validate Sign Up button visibility and clickability."""
        signup_button = self.test.driver.find_element(*GuviLocators.SIGNUP_BUTTON)
        self.assertTrue(signup_button.is_displayed())
        self.assertTrue(signup_button.is_enabled())

    def test_signup_navigation(self):
        """Test Case 5: Navigate using Sign-Up button."""
        signup_button = self.test.driver.find_element(*GuviLocators.SIGNUP_BUTTON)
        signup_button.click()
        self.assertIn("sign-in", self.test.driver.current_url)

    def test_valid_login(self):
        """Test Case 6: Login with valid credentials."""
        self.test.open_url(self.url + "/sign-in/")
        self.test.driver.find_element(*GuviLocators.EMAIL_INPUT).send_keys("valid_email@example.com")
        self.test.driver.find_element(*GuviLocators.PASSWORD_INPUT).send_keys("valid_password")
        self.test.driver.find_element(*GuviLocators.LOGIN_SUBMIT).click()
        self.assertTrue(self.test.driver.find_element(*GuviLocators.LOGOUT_BUTTON).is_displayed())

    def test_invalid_login(self):
        """Test Case 7: Login with invalid credentials."""
        self.test.open_url(self.url + "/sign-in/")
        self.test.driver.find_element(*GuviLocators.EMAIL_INPUT).send_keys("invalid_email@example.com")
        self.test.driver.find_element(*GuviLocators.PASSWORD_INPUT).send_keys("invalid_password")
        self.test.driver.find_element(*GuviLocators.LOGIN_SUBMIT).click()
        error_message = self.test.driver.find_element_by_class_name("error-message")  # Replace class name
        self.assertIn("Invalid credentials", error_message.text)

    @classmethod
    def tearDownClass(cls):
        cls.test.close_browser()

if __name__ == "__main__":
    unittest.main()
