from selenium.webdriver.common.by import By

class GuviLocators:
    """Locators for GUVI website."""
    LOGIN_BUTTON = (By.LINK_TEXT, "Login")
    SIGNUP_BUTTON = (By.LINK_TEXT, "Sign Up")
    EMAIL_INPUT = (By.ID, "email")  # Replace with actual ID
    PASSWORD_INPUT = (By.ID, "password")  # Replace with actual ID
    LOGIN_SUBMIT = (By.ID, "login-submit")  # Replace with actual ID
    LOGOUT_BUTTON = (By.LINK_TEXT, "Logout")  # Replace with actual text
