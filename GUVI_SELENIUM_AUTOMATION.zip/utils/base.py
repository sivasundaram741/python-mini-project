from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class BaseTest:
    """Base class to initialize WebDriver and provide common methods."""

    def __init__(self, browser="chrome"):
        """Initialize the WebDriver."""
        if browser == "chrome":
            self.driver = webdriver.Chrome()
        elif browser == "firefox":
            self.driver = webdriver.Firefox()
        elif browser == "edge":
            self.driver = webdriver.Edge()
        else:
            raise ValueError("Unsupported browser!")

        self.driver.maximize_window()
        self.driver.implicitly_wait(10)

    def open_url(self, url):
        """Open a URL."""
        try:
            self.driver.get(url)
        except Exception as e:
            print(f"Error while opening {url}: {e}")

    def close_browser(self):
        """Close the browser."""
        self.driver.quit()
